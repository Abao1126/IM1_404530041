package bank;

import java.util.ArrayList;

public class BankAccount {
	// declare
	String status;
	int accountNumber;
	private double balance;
	private ArrayList<Double> transactionList = new ArrayList<Double>();

	// constructor
	public BankAccount() {
		this(-1, -1);
	}

	public BankAccount(int anaccountNumber) {
		this(anaccountNumber, -1);
	}

	public BankAccount(int anaccountNumber, double initialBalance) {
		this.status = "open";
		this.accountNumber = anaccountNumber;
		this.balance = initialBalance;

	}

	// determine status
	boolean isOpen() {
		return this.status.equalsIgnoreCase("open");
	}

	boolean isClosed() {
		return this.status.equalsIgnoreCase("closed");
	}

	boolean isSuspended() {
		return this.status.equalsIgnoreCase("suspended");
	}

	void reOpen() {
		this.status = "open";
	}

	void suspend() {
		this.status = "suspended";
	}

	void closed() {
		this.status = "closed";
	}

	// deposit method
	void deposit(double amount) throws Exception {
		if (!this.isOpen() && amount > 0) {
			throw new Exception("transaction:" + this.accountNumber + "deposit fault");
		}
		this.balance += amount;
		addTransaction(amount);

	}

	// withdraw method
	void withdraw(double amount) throws Exception {
		if (!this.isOpen() && amount > 0 && this.balance <= amount) {
			throw new Exception("transaction:" + this.accountNumber + "withdraw fault");
		}
		this.balance -= amount;
		addTransaction(-amount);

	}

	// get the balance
	double getBalance() {
		return this.balance;
	}

	// add transaction to the List
	void addTransaction(double amount) {
		transactionList.add(amount);
	}

	// output the transaction
	String getTransactions() {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < this.transactionList.size(); i++) {
			sb.append((i + 1) + ":  " + this.transactionList.get(i) + "\n");
		}
		return sb.toString();

	}

	// numbers of the transaction
	int retrieveNumberOfTransactions() {
		return this.transactionList.size();
	}
}
