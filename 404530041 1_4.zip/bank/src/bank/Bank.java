package bank;

import java.util.HashMap;

public class Bank {
	// HashMap
	HashMap<Integer, BankAccount> BankList = new HashMap<Integer, BankAccount>();

	// addAccount
	void addAccount(int accountNumber, double initialBalance) {
		if (initialBalance < 0)
			initialBalance = 0;
		BankList.put(accountNumber, new BankAccount(accountNumber, initialBalance));
	}

	// deposit
	void deposit(int accountNumber, double initialBalance) {
		BankAccount client = (BankAccount) BankList.get(accountNumber);
		try {
			client.deposit(initialBalance);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	// withdraw
	void withdraw(int accountNumber, double initialBalance) {
		BankAccount client = (BankAccount) BankList.get(accountNumber);
		try {
			client.withdraw(initialBalance);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	// get balance
	double getBalance(int accountNumber) {
		BankAccount client = (BankAccount) BankList.get(accountNumber);
		return client.getBalance();
	}

	// suspend
	void suspendAccount(int accountNumber) {
		BankAccount client = (BankAccount) BankList.get(accountNumber);
		client.suspend();
	}

	// reopen the account
	void reOpenAccount(int accountNumber) {
		BankAccount client = (BankAccount) BankList.get(accountNumber);
		client.reOpen();
	}

	// close the account
	void closeAccount(int accountNumber) {
		BankAccount client = (BankAccount) BankList.get(accountNumber);
		client.closed();
	}

	// get account's status
	String getAccountStatus(int accountNumber) {
		BankAccount client = (BankAccount) BankList.get(accountNumber);
		return client.status;
	}

	// summarize Account Transactions
	String summarizeAccountTransactions(int accountNumber) {
		StringBuffer sb = new StringBuffer();
		BankAccount client = (BankAccount) BankList.get(accountNumber);
		sb.append("\n\nAccount#  " + accountNumber + "\ttransaction\n\n");
		sb.append(client.getTransactions());
		sb.append("End of transactions\n\n");
		return sb.toString();
	}

	// summarize All Accounts
	String summarizeAllAccounts() {
		StringBuffer sb = new StringBuffer();
		sb.append("Bank Account Summary\n\n");
		sb.append("Account\t\tBalance\t\t#Transactions\t\tStatus\n\n");
		for (BankAccount bank : BankList.values()) {
			sb.append(bank.accountNumber + "\t\t");
			sb.append(bank.getBalance() + "\t\t");
			sb.append(bank.retrieveNumberOfTransactions() + "\t\t\t");
			sb.append(bank.status + "\n\n");
		}
		sb.append("End of  Account Summary");
		return sb.toString();
	}
}
