package grade;
import javax.swing.JOptionPane;
public class GradeAnalzerTester 
{
	public static void main(String []args)
	{
		//new object 
		GradeAnalyzer GA = new GradeAnalyzer();
		
		//set input
		while(true)
		{
			//GUI
			String inputnumber=JOptionPane.showInputDialog(null,"input number");
			
			//string compare
			if (inputnumber.equals("q"))
			{
				//call method
				GA.analyzerGrade();
				System.out.println(GA.toString());
				break;
			}
			else
			{
				//call method
				GA.isValidGrade(Double.parseDouble(inputnumber));
				GA.addGrade(Double.parseDouble(inputnumber));
			}
		}
	}
}

